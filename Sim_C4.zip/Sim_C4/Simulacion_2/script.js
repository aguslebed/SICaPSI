const ESCENAS = { 
  inicio: {
    video: "videos/21.mp4",
    texto: "Situación inicial: Delivery deja paquete sin destinatario.",
    opciones: [
      { label: "Verificar destinatario en lista", puntos: +5, next: "verificar" },
      { label: "Manipular sin protocolo", puntos: -10, next: "camino_incorrecto" }
    ]
  },

  verificar: {
    video: "videos/22.mp4",
    texto: "✔ Guardia: “No está registrado, voy a chequear.”",
    opciones: [
      { label: "Revisar cámaras", puntos: +5, next: "camaras" }
    ]
  },

  camino_incorrecto: {
    video: "videos/23.mp4",
    texto: "❌ Guardia: “Lo reviso yo mismo.” — Incorrecto: manipulaste el paquete sin protocolo.",
    opciones: null,
    fin: true,
    bonus: -20
  },

  camaras: {
    video: "videos/25.mp4",
    texto: "✔ Guardia: “A las 14:32 lo dejó un repartidor sin firmar.”",
    opciones: [
      { label: "Notificar al consorcio y registrar", puntos: +10, next: "consorcio" },
      { label: "Llamar Policía", puntos: +5, next: "policia" }
    ]
  },

  consorcio: {
    video: "videos/26.mp4",
    texto: "✔ Guardia: “Administrador, quedó un paquete sin destinatario.” ✅",
    opciones: null,
    fin: true,
    bonus: +20
  },

  policia: {
    video: "videos/27.mp4",
    texto: "⚠ Guardia: “911, objeto sospechoso en hall.” — Consecuencia: Patrullero llega, vecinos molestos.",
    opciones: null,
    fin: true,
    bonus: -5
  }
};

// --- Referencias del DOM ---
const videoEl   = document.getElementById("videoEscena");
const sourceEl  = document.getElementById("videoSource");
const textoEl   = document.getElementById("textoEscena");
const btnA      = document.getElementById("btnA");
const btnB      = document.getElementById("btnB");
const puntajeEl = document.getElementById("puntaje");
const rutaEl    = document.getElementById("ruta");
const opcionesDiv = document.getElementById("opciones");

let estado = { escenaId: "inicio", puntaje: 0, ruta: ["inicio"] };

// --- Cargar escena ---
function cargarEscena(id) {
  const escena = ESCENAS[id];
  if (!escena) return;

  estado.escenaId = id;
  if (estado.ruta[estado.ruta.length - 1] !== id) estado.ruta.push(id);

  sourceEl.src = escena.video;
  videoEl.load();
  videoEl.play().catch(() => {});

  textoEl.textContent = escena.texto;
  rutaEl.textContent = "Ruta: " + estado.ruta.join(" → ");
  puntajeEl.textContent = "Puntaje: " + estado.puntaje;

  if (escena.fin || !escena.opciones) {
    estado.puntaje += escena.bonus || 0;
    puntajeEl.textContent = "Puntaje final: " + estado.puntaje;

    btnA.style.display = "none";
    btnB.style.display = "none";

    videoEl.onended = () => mostrarFin();
  } else {
    btnA.style.display = "inline-block";
    btnB.style.display = escena.opciones[1] ? "inline-block" : "none";

    btnA.textContent = escena.opciones[0].label;
    btnA.onclick = () => elegir(0);
    if (escena.opciones[1]) {
      btnB.textContent = escena.opciones[1].label;
      btnB.onclick = () => elegir(1);
    }
  }
}

// --- Seleccionar opción ---
function elegir(indice) {
  const escena = ESCENAS[estado.escenaId];
  if (!escena || !escena.opciones) return;

  const opcion = escena.opciones[indice];
  estado.puntaje += opcion.puntos || 0;
  puntajeEl.textContent = "Puntaje: " + estado.puntaje;
  cargarEscena(opcion.next);
}

// --- Mostrar fin con botón de reinicio ---
function mostrarFin() {
  textoEl.textContent = " Simulación completada.";
  rutaEl.textContent = "Ruta: " + estado.ruta.join(" → ");
  puntajeEl.textContent = "Puntaje final: " + estado.puntaje;

  opcionesDiv.innerHTML = `
    <button id="reiniciarBtn" style="
      background-color:#2563eb;
      color:white;
      border:none;
      padding:10px 20px;
      border-radius:8px;
      cursor:pointer;
      margin-top:10px;
      font-weight:600;
    "> Reiniciar</button>
  `;

  const reiniciarBtn = document.getElementById("reiniciarBtn");
  reiniciarBtn.onclick = reiniciar;
}

// --- Reiniciar simulación ---
function reiniciar() {
  estado = { escenaId: "inicio", puntaje: 0, ruta: ["inicio"] };
  opcionesDiv.innerHTML = `
    <button id="btnA">Opción 1</button>
    <button id="btnB">Opción 2</button>
  `;
 
  window.location.reload(); 
}

// --- Iniciar ---
cargarEscena("inicio");
