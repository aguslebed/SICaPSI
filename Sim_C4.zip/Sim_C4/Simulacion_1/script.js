const ESCENAS = {
  // Nivel 1
  inicio: {
    video: "videos/1.mp4",
    texto: "Situación inicial: Un hombre llega al hall y pide entrar a visitar a un amigo.",
    opciones: [
      { label: "Solicitar DNI", puntos: +5, next: "verificar" },
      { label: "Negar ingreso sin identificación", puntos: +5, next: "rechazo" }
    ]
  },

  // Nivel 2
  verificar: {
    video: "videos/2.mp4",
    texto: "✔ Ley 12.297, art. 5\nGuardia: 'Buenos dias, ¿me muestra su DNI?'",
    opciones: [
      { label: "Confirmar con propietario", puntos: +5, next: "confirmar" },
      { label: "Permitir ingreso sin confirmar", puntos: -5, next: "camino_incorrecto1" }
    ]
  },

  camino_incorrecto1: {
    video: "videos/6.mp4", 
    texto: "❌ Incorrecto: Permitiste el ingreso sin autorización del propietario.",
    opciones: null,
    fin: true,
    bonus: -15
  },

  // Nivel 3
  confirmar: {
    video: "videos/3.mp4",
    texto: "✔ Art. 5\nGuardia (por portero): '¿Autoriza el ingreso del Sr. López?'",
    opciones: [
      { label: "Registrar ingreso en libro", puntos: +10, next: "registrar" },
      { label: "No registrar", puntos: -10, next: "camino_incorrecto3" }
    ]
  },

  camino_incorrecto2: {
    video: "videos/6.mp4",
    texto: "❌ Incorrecto: Autorizaste el ingreso pero no lo registraste en el libro.",
    opciones: null,
    fin: true,
    bonus: -10
  },

  rechazo: {
    video: "videos/7.mp4", 
    texto: "✔ Correcto\nGuardia: 'Lo lamento, sin documento no puedo permitirle el ingreso.'",
    opciones: null,
    fin: true,
    bonus: 0
  },

  // Nivel 4
  registrar: {
    video: "videos/4.mp4",
    texto: "✔ Decreto Reglamentario, art. 9\nGuardia: 'Hora 20:15, ingreso autorizado Dpto. 8B.'",
    opciones: [
      { label: "Confirmar registro", puntos: +10, next: "final_ok" },
      { label: "Cancelar registro", puntos: -20, next: "camino_incorrecto3" }
    ]
  },
    camino_incorrecto3: {
    video: "videos/6.mp4",
    texto: "❌ Incorrecto: Autorizaste el ingreso pero no lo registraste en el libro.",
    opciones: null,
    fin: true,
    bonus: -10
  },

  // Finales
  final_ok: {
    video: "videos/5.mp4",
    texto: "Ingreso correctamente registrado ✅",
    opciones: null,
    fin: true,
    bonus: +20
  }
};

// -------------------------
// Lógica principal
// -------------------------
const videoEl   = document.getElementById("videoEscena");
const sourceEl  = document.getElementById("videoSource");
const textoEl   = document.getElementById("textoEscena");
const btnA      = document.getElementById("btnA");
const btnB      = document.getElementById("btnB");
const puntajeEl = document.getElementById("puntaje");
const rutaEl    = document.getElementById("ruta");

let estado = { escenaId: "inicio", puntaje: 0, ruta: ["inicio"] };

function cargarEscena(id) {
  const escena = ESCENAS[id];
  if (!escena) return;

  estado.escenaId = id;
  if (estado.ruta[estado.ruta.length - 1] !== id) estado.ruta.push(id);

  sourceEl.src = escena.video;
  videoEl.load();
  videoEl.play().catch(() => {});

  textoEl.textContent = escena.texto;
  rutaEl.textContent = "Ruta: " + estado.ruta.join(" → ");
  puntajeEl.textContent = "Puntaje: " + estado.puntaje;

  if (escena.fin || !escena.opciones) {
    estado.puntaje += escena.bonus || 0;
    puntajeEl.textContent = "Puntaje: " + estado.puntaje;

    btnA.style.display = "none";
    btnB.style.display = "none";

    videoEl.onended = () => mostrarFin();
  } else {
    btnA.style.display = "inline-block";
    btnB.style.display = "inline-block";

    btnA.textContent = escena.opciones[0].label;
    btnB.textContent = escena.opciones[1].label;

    btnA.onclick = () => elegir(0);
    btnB.onclick = () => elegir(1);
  }
}

function elegir(indice) {
  const escena = ESCENAS[estado.escenaId];
  if (!escena || !escena.opciones) return;

  const opcion = escena.opciones[indice];
  estado.puntaje += opcion.puntos || 0;
  puntajeEl.textContent = "Puntaje: " + estado.puntaje;
  cargarEscena(opcion.next);
}

function mostrarFin() {
  textoEl.textContent = "Simulación completada.";
  rutaEl.textContent = "Ruta: " + estado.ruta.join(" → ");
  puntajeEl.textContent = "Puntaje final: " + estado.puntaje;

  document.getElementById("opciones").innerHTML =
    `<button onclick="location.reload()">Reiniciar</button>`;
}

// Iniciar simulación
cargarEscena("inicio");
