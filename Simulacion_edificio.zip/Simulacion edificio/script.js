const ESCENAS = {
  // Nivel 1
  inicio: {
    video: "videos/v1.mp4",
    texto: "Una persona vestida de oficial de policia toca la puerta.",
    opciones: [
      { label: "Acercarse y abrir la puerta", puntos: +5, next: "x" },
      { label: "Acercarse sin abrir la puerta", puntos: 0, next: "y" }
    ]
  },

  // Nivel 2
  x: {
    video: "videos/v2.mp4",
    texto: "",
    opciones: [
      { label: "Pedir identificacion", puntos: +5, next: "xx" },
      { label: "Dejar pasar", puntos: -5, next: "xy" }
    ]
  },
  y: {
    video: "videos/v6.mp4",
    texto: "",
    opciones: [
      { label: "Comunicarse a travez del vidrio", puntos: +5, next: "yx" },
      { label: "Pedirle que se retire", puntos: -5, next: "yy" }
    ]
  },

  // Nivel 3
  xx: {
    video: "videos/v3.mp4",
    texto: "Notas que la identificacion es falsa.",
    opciones: [
      { label: "Dejar entrar igualmente", puntos: 0, next: "xxx" },
      { label: "Denegar acceso", puntos: +10, next: "xxy" }
    ]
  },
  xy: {
    video: "videos/v7.mp4",
    texto: "",
    opciones: [
      { label: "Anotar ingreso", puntos: +5, next: "xyx" },
      { label: "No anotar y volver al puesto", puntos: -5, next: "xyy" }
    ]
  },
  yx: {
    video: "videos/video6.mp4",
    texto: "",
    opciones: [
      { label: "Opción 1", puntos: +5, next: "yxx" },
      { label: "Opción 2", puntos: 0, next: "yxy" }
    ]
  },
  yy: {
    video: "videos/video7.mp4",
    texto: "",
    opciones: [
      { label: "Opción 1", puntos: +5, next: "yyx" },
      { label: "Opción 2", puntos: -10, next: "yyy" }
    ]
  },

  xxx: { video: "videos/v4.mp4",  texto: "Final XXX", opciones: null, fin: true, bonus: +10 },
  xxy: { video: "videos/v5.mp4",  texto: "Final XXY", opciones: null, fin: true, bonus: 0 },
  xyx: { video: "videos/v8.mp4", texto: "Final XYX", opciones: null, fin: true, bonus: +5 },
  xyy: { video: "videos/v9.mp4", texto: "Final XYY", opciones: null, fin: true, bonus: -5 },
  yxx: { video: "videos/video12.mp4", texto: "Final YXX", opciones: null, fin: true, bonus: +5 },
  yxy: { video: "videos/video13.mp4", texto: "Final YXY", opciones: null, fin: true, bonus: 0 },
  yyx: { video: "videos/video14.mp4", texto: "Final YYX", opciones: null, fin: true, bonus: +8 },
  yyy: { video: "videos/video15.mp4", texto: "Final YYY", opciones: null, fin: true, bonus: -10 }
};

const videoEl   = document.getElementById("videoEscena");
const sourceEl  = document.getElementById("videoSource");
const textoEl   = document.getElementById("textoEscena");
const btnA      = document.getElementById("btnA");
const btnB      = document.getElementById("btnB");
const puntajeEl = document.getElementById("puntaje");
const rutaEl    = document.getElementById("ruta");

let estado = { escenaId: "inicio", puntaje: 0, ruta: ["inicio"] };

function cargarEscena(id) {
  const escena = ESCENAS[id];
  if (!escena) return;

  estado.escenaId = id;
  if (estado.ruta[estado.ruta.length - 1] !== id) estado.ruta.push(id);

  sourceEl.src = escena.video;
  videoEl.load();
  videoEl.play().catch(() => {});

  textoEl.textContent = escena.texto;
  rutaEl.textContent = "Ruta: " + estado.ruta.join(" → ");
  puntajeEl.textContent = "Puntaje: " + estado.puntaje;

  if (escena.fin || !escena.opciones) {
    estado.puntaje += escena.bonus || 0;
    puntajeEl.textContent = "Puntaje: " + estado.puntaje;

    btnA.style.display = "none";
    btnB.style.display = "none";

    videoEl.onended = () => mostrarFin();
  } else {
    btnA.style.display = "inline-block";
    btnB.style.display = "inline-block";

    btnA.textContent = escena.opciones[0].label;
    btnB.textContent = escena.opciones[1].label;

    btnA.onclick = () => elegir(0);
    btnB.onclick = () => elegir(1);
  }
}

function elegir(indice) {
  const escena = ESCENAS[estado.escenaId];
  if (!escena || !escena.opciones) return;

  const opcion = escena.opciones[indice];
  estado.puntaje += opcion.puntos || 0;
  puntajeEl.textContent = "Puntaje: " + estado.puntaje;
  cargarEscena(opcion.next);
}

function mostrarFin() {
  textoEl.textContent = "Simulación completada.";
  rutaEl.textContent = "Ruta: " + estado.ruta.join(" → ");
  puntajeEl.textContent = "Puntaje final: " + estado.puntaje;

  document.getElementById("opciones").innerHTML =
    `<button onclick="location.reload()">Reiniciar</button>`;
}

cargarEscena("inicio");
