const mongoose = require('mongoose');
const { Schema } = mongoose;

const UsuarioBaseSchema = new Schema({
  legajo: { type: Number, unique: true },
  tipo: { type: String, enum: ['administrador', 'directivo', 'capacitador', 'guardia'], required: true },
  nombre: String,
  apellido: String,
  mail: String,
  contraseña: String,
  fechaNacimiento: Date,
  fechaCreacion: { type: Date, default: Date.now },
  direccion: String,
  telefono: Number,
  dni: Number,
  ultimoIngreso: Date
}, { discriminatorKey: 'tipo', timestamps: true });

module.exports = mongoose.model('Usuario', UsuarioBaseSchema);